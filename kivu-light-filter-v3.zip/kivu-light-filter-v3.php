<?php
/**
 * Plugin Name: Kivu Light Product Filter V3
 * Description: Lightweight, duplicate-free homepage product filter for Kivu Agro Bio.
 * Version: 1.0.0
 * Author: Codex
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_footer', function () {
    if (!is_front_page() && !is_page(4618)) {
        return;
    }
    ?>
<style id="kab-light-filter-v3-css">
body.page-id-4618 .kab-product-filter{width:min(1120px,calc(100% - 32px))!important;margin:28px auto 18px!important;padding:14px!important;background:#fff!important;border:1px solid rgba(31,122,58,.16)!important;border-radius:8px!important;box-shadow:0 12px 34px rgba(18,63,36,.08)!important}
body.page-id-4618 .kab-product-filter__top{display:grid!important;grid-template-columns:minmax(0,1fr) auto!important;gap:12px!important;align-items:end!important}
body.page-id-4618 .kab-product-filter label{margin:0 0 7px!important;font-size:11px!important;letter-spacing:.08em!important;color:#1f7a3a!important;font-weight:850!important;text-transform:uppercase!important}
body.page-id-4618 .kab-product-filter input{height:44px!important;border-radius:6px!important;background:#fbfaf6!important;border:1px solid rgba(31,122,58,.22)!important;padding:0 13px!important;font-size:14px!important}
body.page-id-4618 .kab-filter-count{min-width:104px!important;height:44px!important;display:flex!important;align-items:center!important;justify-content:center!important;border-radius:6px!important;background:#123f24!important;color:#fff!important;font-size:13px!important;font-weight:850!important;padding:0 12px!important}
body.page-id-4618 .kab-filter-buttons{display:flex!important;gap:7px!important;overflow-x:auto!important;flex-wrap:nowrap!important;margin-top:11px!important;padding:2px 0 4px!important;scrollbar-width:thin!important}
body.page-id-4618 .kab-filter-buttons button{flex:0 0 auto!important;border:1px solid rgba(31,122,58,.18)!important;background:#fff!important;color:#123f24!important;border-radius:999px!important;padding:8px 11px!important;font-size:12px!important;font-weight:800!important;line-height:1!important;cursor:pointer!important}
body.page-id-4618 .kab-filter-buttons button.is-active{background:#1f7a3a!important;color:#fff!important;border-color:#1f7a3a!important}
body.page-id-4618 .kab-live-results{display:none;width:min(1120px,calc(100% - 32px));margin:16px auto 28px}
body.page-id-4618.kab-filtering-active .kab-live-results{display:grid!important;grid-template-columns:repeat(auto-fill,minmax(210px,1fr))!important;gap:18px!important;align-items:stretch!important}
body.page-id-4618.kab-filtering-active .elementor-section-boxed:not(.elementor-element-kabf001):not(.elementor-element-kabp001):has(.elementor-widget-image-box){display:none!important}
body.page-id-4618 .kab-live-results .elementor-widget-image-box{display:block!important;width:100%!important;margin:0!important}
body.page-id-4618 .kab-live-results .elementor-image-box-wrapper{min-height:320px!important}
body.page-id-4618 .kab-empty-result{grid-column:1/-1;background:#fff7e6;border:1px solid rgba(214,162,58,.32);border-radius:8px;padding:16px;color:#65440d;font-weight:750}
@media(max-width:720px){body.page-id-4618 .kab-product-filter__top{grid-template-columns:1fr!important}body.page-id-4618 .kab-filter-count{justify-content:flex-start!important}body.page-id-4618.kab-filtering-active .kab-live-results{grid-template-columns:repeat(auto-fill,minmax(160px,1fr))!important;gap:14px!important}}
</style>
<script id="kab-light-filter-v3-js">
(function(){
  if (window.kabLightFilterV3) return;
  window.kabLightFilterV3 = true;
  var tabs=[["all","Tous"],["sexualite","Sexualit\u00e9"],["surpoids","Surpoids"],["diabete","Diab\u00e8te"],["hypertension","Hypertension"],["reinsfoie","Reins & foie"],["surpoidsdigestion","Surpoids & digestion"],["peau","Peau & cheveux"],["huile","Huiles"],["beurre","Beurres"],["savon","Savons"]];
  var labels={sexualite:"sexualite libido fertilite vitalite",surpoids:"surpoids minceur poids",surpoidsdigestion:"surpoids digestion ventre",diabete:"diabete glycemie sucre",hypertension:"hypertension tension pression",reinsfoie:"reins foie detox",peau:"peau cheveux",huile:"huile",beurre:"beurre",savon:"savon"};
  var map={
    sexualite:["libido power","full energie","maca","ginseng","petit cola","noix de cola","antibiotique naturel","body booster","beurre de fenugrec au kigelia","huile de carapace de tortue"],
    surpoids:["graines de chia","full detox","graines de lin","pulpe de baobab","cannelle","fenugrec","huile de nigelle","argile verte"],
    surpoidsdigestion:["graines de chia","full detox","gingembre","basilic sacre","aubergine sauvage","graines de lin","huile de nigelle","argile verte"],
    diabete:["baobab","cannelle","fenugrec","moringa en poudre","maca","stevia","full detox","contre le diabete"],
    hypertension:["moringa en poudre","graines de moringa","graines de nigelle","huile de nigelle","hibiscus","bisap","bissap","maca","cacao","masala","contre hypertension"],
    reinsfoie:["roi des herbes","ortie","huile de nigelle","curcuma","aubergine sauvage"],
    peau:["huile de curcuma","huile de moringa","huile de neem","huile de fenugrec","huile de ricin","huile de nigelle","huile de kigelia","huile de baobab","huile de clous de girofle","mafuta ya ngombe","beurre de karite","beurre de fenugrec au kigelia","beurre de karite au curcuma","huile de coco","savon noir","savon de curcuma","savon de moringa"]
  };
  function n(s){return(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g," ").trim()}
  function titleOf(card){var e=card.querySelector(".elementor-image-box-title,h3,h4");return e?e.textContent.trim():""}
  function sourceCards(){var seen={};return Array.from(document.querySelectorAll(".elementor-widget-image-box")).filter(function(card){if(card.closest(".kab-live-results"))return false;var t=n(titleOf(card));if(!t||seen[t])return false;seen[t]=true;return true})}
  function catsFor(title){var t=n(title),out=[];Object.keys(map).forEach(function(k){if(map[k].some(function(v){return t.indexOf(n(v))>-1}))out.push(k)});if(t.indexOf("huile")>-1)out.push("huile");if(t.indexOf("beurre")>-1)out.push("beurre");if(t.indexOf("savon")>-1)out.push("savon");return out.filter(function(x,i,a){return a.indexOf(x)===i})}
  function ensure(){var box=document.querySelector(".kab-product-filter");if(!box)return null;var buttons=box.querySelector(".kab-filter-buttons");if(buttons)buttons.innerHTML=tabs.map(function(r,i){return'<button type="button" data-filter="'+r[0]+'" class="'+(i?'':'is-active')+'">'+r[1]+"</button>"}).join("");var grid=document.querySelector(".kab-live-results");if(!grid){grid=document.createElement("div");grid.className="kab-live-results";box.insertAdjacentElement("afterend",grid)}return{box:box,buttons:buttons,grid:grid,input:box.querySelector("input"),count:box.querySelector(".kab-filter-count,#kab-filter-count")}}
  function init(){var ui=ensure();if(!ui||!ui.buttons||!ui.input)return;var active="all";
    function render(){var q=n(ui.input.value),cards=sourceCards(),matches=[];cards.forEach(function(card){var t=titleOf(card),cats=catsFor(t),terms=cats.map(function(c){return(labels[c]||"")+" "+((map[c]||[]).join(" "))}).join(" "),search=n([t,(card.closest(".kab-filter-item")||card).dataset.kabSearch||"",terms].join(" "));if((active==="all"||cats.indexOf(active)>-1)&&(!q||search.indexOf(q)>-1))matches.push(card)});ui.buttons.querySelectorAll("button").forEach(function(b){b.classList.toggle("is-active",b.dataset.filter===active)});var filtering=active!=="all"||q;document.body.classList.toggle("kab-filtering-active",filtering);ui.grid.innerHTML="";if(!filtering){if(ui.count)ui.count.textContent=cards.length+" produits";return}if(ui.count)ui.count.textContent=matches.length+" produit"+(matches.length>1?"s":"");if(!matches.length){ui.grid.innerHTML='<div class="kab-empty-result">Aucun produit trouv\\u00e9. Essayez un nom de produit ou un besoin.</div>';return}matches.forEach(function(card){var clone=card.cloneNode(true);clone.classList.remove("kab-product-hidden");clone.removeAttribute("style");ui.grid.appendChild(clone)})}
    ui.buttons.addEventListener("click",function(e){var b=e.target.closest("button[data-filter]");if(!b)return;e.preventDefault();e.stopPropagation();active=b.dataset.filter||"all";render()},true);
    ui.input.addEventListener("input",render,true);
    window.kabLightFilterApply=function(slug){active=slug||"all";render();return Array.from(ui.grid.querySelectorAll(".elementor-image-box-title,h3,h4")).map(function(e){return e.textContent.trim()})};
    render();
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",function(){setTimeout(init,900)});else setTimeout(init,900);
})();
</script>
    <?php
}, 3000);
